package com.accountdetails.client;

public class UserServiceProxy {

}
