package com.accountdetails.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.accountdetails.model.Account;
import com.accountdetails.model.User;
import com.accountdetails.model.UserAccountInfo;
import com.accountdetails.service.UserService;
import com.accountdetails.vo.UserVO;


@RestController
public class UserController {

	@Autowired
	UserService UserService;
	@GetMapping(value = "/User", produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<User> getUserDetails() {

		
		
		User User = UserService.getUserDetails();
		
		return new ResponseEntity(User, HttpStatus.OK);
		
	}
	
	@PostMapping(value = "/User", produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<User> saveUserDetails(@RequestBody UserAccountInfo userAccountInfo) {

		
		
		
		
		//saving account info this mi
		Account account = UserService.saveUserDetails(userAccountInfo);
		
		return new ResponseEntity(account, HttpStatus.CREATED);
		
	}

	@PutMapping(value = "/User", produces = {MediaType.APPLICATION_JSON_VALUE})
	public ResponseEntity<User> modifyUserDetails(@RequestBody UserVO UserVO) {
	
		
		User User = UserService.modifyUserDetails(UserVO);
		
		return new ResponseEntity(User, HttpStatus.ACCEPTED);
		
	}

}
