package com.accountdetails.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.accountdetails.model.Account;

public interface IAccountRepository extends JpaRepository<Account, String>{

}
