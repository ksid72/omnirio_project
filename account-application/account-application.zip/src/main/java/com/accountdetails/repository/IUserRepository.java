package com.accountdetails.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.accountdetails.model.User;

public interface IUserRepository extends JpaRepository<User, String>{

}
