package com.accountdetails.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.accountdetails.model.Account;
import com.accountdetails.model.User;
import com.accountdetails.model.UserAccountInfo;
import com.accountdetails.repository.IAccountRepository;
import com.accountdetails.vo.UserVO;

@Service
public class UserService {
	
	@Autowired
	IAccountRepository accountRepository;

	public User getUserDetails() {

		return new User();
	}

	public Account saveUserDetails(UserAccountInfo userAccountInfo) {

		
		
		return accountRepository.save(userAccountInfo.getAccount());
		
		
		
	}

	public User modifyUserDetails(UserVO Uservo) {

		User User = new User();

		return User;
	}

}
